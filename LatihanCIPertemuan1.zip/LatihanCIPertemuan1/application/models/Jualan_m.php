<?php
class Jualan_m extends CI_Model{
    function get_produk(){
        //select data
        //menampilkan data dalam bentuk array 
        //menampilkan dlam bentuk object
        $result = $this->db->get('produk')->result_array();
        return $result;
    }
}