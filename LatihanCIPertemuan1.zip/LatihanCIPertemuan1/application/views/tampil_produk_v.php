<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title; ?></title>
</head>
<body>
    <table border='1' width='100%'>
    <tr>
        <td>Kode Produk</td>
        <td>Nama Produk</td>
        <td>Harga Produk</td>
        <td>Stok Produk</td>
    </tr>
    <?php
    foreach($produk as $resultproduk){
    ?>
    <tr>
        <td><?= $resultproduk['KodeProduk'] ?></td>
        <td><?= $resultproduk['NamaProduk'] ?></td>
        <td><?= $resultproduk['Harga'] ?></td>
        <td><?= $resultproduk['Stok'] ?></td>
    </tr>
    <?php }?>
    </table>
</body>
</html>