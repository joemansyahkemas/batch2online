<h1><?php echo $judul; ?></h1>
<p><?= $tema; ?></p>