Aplikasi kalkulator
<form method="POST" action="<?= base_url('index.php/home/proseskalkulator') ?>">
    <label>Angka 1</label>
    <input type="number" name="angka1" required/>
    <label>Angka 2</label>
    <input type="number" name="angka2" required/>
    <select name="operator" required>
        <option value=""> Pilih Operator</option>
        <option value="+">(+)Penjumlahan</option>
        <option value="-">(-)Pengurangan</option>
        <option value="*">(*)Perkalian</option>
    </select>
    <button type="submit" name="hitung">Hitung</button>
    <button type="reset">Clear</button>
</form>