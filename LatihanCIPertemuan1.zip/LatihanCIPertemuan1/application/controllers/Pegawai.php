<?php
//nama class harus sama dengan nama file dan nama class diawali dengan huruf besar
class Pegawai extends CI_Controller{
    public function index(){
        $this->load->view('pegawai_v');
    }
    public function proses(){
        $namapegawai  = $this->input->post('nama');
        $lama_bekerja = $this->input->post('lama_bekerja');
        $tanggungan_anak = $this->input->post('tanggungan_anak');
        echo $namapegawai.'<br>';
        echo $lama_bekerja.'<br>';
        echo $tanggungan_anak.'<br>';
        echo "<a href='index'>kembali</a>";
    }
}