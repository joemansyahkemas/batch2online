<?php
class Home extends CI_Controller {

    // untuk default controller wajib ada method atau fungsi index
    public function index(){
        // pemanggilan view
        $this->load->view('beranda_v');
    }
    // pemanggilan variable di URL nama variable bebas yang penting urutan variablenya
    public function profil($nomor,$idprofil){
        $isi = 'Keterangan perusahaan';
        $data = array(
            'judul' => 'Halaman Profil perusahaan PT bla bla bla',
            'tema' => $nomor.$idprofil
        );
        $this->load->view('pages/profil_v',$data);
    }
    public function kalkulator(){
        $this->load->view('pages/kalkulator_v');
    }
    public function proseskalkulator(){
        $angka1 = $this->input->post('angka1');
        $angka2 = $this->input->post('angka2');
        $operator = $this->input->post('operator');
        if($operator == '+'){
            $hasil = $angka1 + $angka2;
        }elseif($operator == '-'){
            $hasil = $angka1 - $angka2;
        }else{
            $hasil = $angka1 * $angka2;
        }
        echo "Hasil perhitungan dari $angka1 $operator $angka2 adalah $hasil";
    }
}