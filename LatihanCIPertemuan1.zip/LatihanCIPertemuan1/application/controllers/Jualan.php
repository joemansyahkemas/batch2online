<?php 
class Jualan extends CI_Controller{
    function __construct(){
        parent::__construct();
        $this->load->model('Jualan_m');
    }
    function index(){
        $data = array(
            'title' => 'Data Produk',
            'produk' => $this->Jualan_m->get_produk(),
        );
        $this->load->view('tampil_produk_v',$data);
    }
}