<?php
defined('BASEPATH') OR exit('No direct script access allowed');

// nama controller
// satu file controller hanya boleh satu class
class Welcome extends CI_Controller {
	//method atau fungsi
	public function index()
	{
		$this->load->view('welcome_message');
	}
}